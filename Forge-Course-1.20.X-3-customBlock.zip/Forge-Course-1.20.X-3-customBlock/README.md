<a href="https://courses.kaupenjoe.net/p/modding-by-kaupenjoe-forge-modding-for-minecraft-1-20-x" target="_blank">
<p align="center">
<img src="https://kaupenjoe.net/files/General/Minecraft/Modding/Course/forge-120x-course-image.jpg" alt="Logo" width="1000"/> 
</p></a>

# Modding by Kaupenjoe: Minecraft 1.20.X Modding Course with Forge
This is the GitHub Repository for Kaupenjoe's Minecraft Modding Course using Forge for version 1.20.X. 

It covers a variety of Topics, from Custom Tools, to Custom Armor, all the way to Custom Block Entities and Custom Mobs. 

The Source Code will always be freely available under the MIT-License, but to support me you can buy the Course which gets you almost 12 Hours of Video Lectures with more to come!

Take a look at the Course right here: <a href="https://courses.kaupenjoe.net/p/modding-by-kaupenjoe-forge-modding-for-minecraft-1-20-x" target="_blank">COURSE</a>